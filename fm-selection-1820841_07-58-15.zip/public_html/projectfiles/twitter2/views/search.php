<div class="container mainContainer">

    <div class="row">
    <div class="col-md-5">
        
        <?php displaySearch(); ?>
      
      <hr>
        
        </div>
  <div class="col-md-7">
        
        <h2>Search Results</h2>
        
        <?php displayTweets('search'); ?>
      
        </div>
  
</div>
    
</div>