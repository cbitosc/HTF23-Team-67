<div class="container mainContainer">

    <div class="row">
  
  <div class="col-md-5">
        
        <?php displaySearch(); ?>
      
      <hr>
      
      <?php displayTweetBox(); ?>
        
        </div>
        <div class="col-md-7">
        
        <h2 style="color:rgb(25,25,112)">Recent talks</h2>
        
        <?php displayTweets('public'); ?>
      
        </div>
</div>
    
</div>