<div class="container mainContainer">

    <div class="row">
  
  <div class="col-md-5">
        
        <?php displaySearch(); ?>
      
      <hr>
      
      <?php displayTweetBox(); ?>
        
        </div>
        <div class="col-md-7">
        
        <h2>Your talks</h2>
        
        <?php displayTweets('yourtweets'); ?>
      
        </div>
</div>
    
</div>