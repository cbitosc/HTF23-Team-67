<?php
     $_SESSION["email"] = '';
     echo "LOGOUT SUCCESSFUL!"
?>